import json

def reg_multiple():
   data_json = json.loads(open('aircraft_data.json').read())
   print(data_json)


print(reg_multiple())
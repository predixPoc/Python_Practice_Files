# -*- coding: utf-8 -*-

def demo(x):
    for i in range(5):
        print("i={}, x={}".format(i, x))
        x = x + 1

demo(0)



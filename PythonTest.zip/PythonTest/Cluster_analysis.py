import pandas as pd
import matplotlib.pyplot as mp
import numpy as np

from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn import metrics 

#Data import .csv file
data = pd.read_csv('cluster_data.csv')
#Show the column names
print(data.columns.values)
# Show total number of records
print(data.count())

vertical_acceleration = data['Vertical Acceleration'].values 
airspeed = data['Airspeed'].values 
#mp.scatter(airspeed,vertical_acceleration)
#mp.xlabel('Airspeed')
#mp.ylabel('Vertical Acceleration')
#mp.title('Airspeed Vs Vertical Acceleration')
#mp.show()
speed_va_1 = data[['Airspeed','Vertical Acceleration']]
speed_va_1.head()

num_clusters = 4 
km = KMeans(n_clusters=num_clusters, init='k-means++', max_iter=100, n_init=1)
km.fit(speed_va_1)
print(km.labels_)
mp.scatter(airspeed, vertical_acceleration,c=km.labels_)
mp.xlabel('Airspeed')
mp.ylabel('Vertical Acceleration')
mp.title('Airspeed Vs Vertical Acceleration')
mp.show()
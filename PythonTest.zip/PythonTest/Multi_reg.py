import numpy as np
#import statsmodels.api as sm
from statsmodels.regression.linear_model import OLS
from statsmodels.tools.tools import add_constant
#y = [1,2,3,4,3,4,5,4,5,5,4,5,4,5,4,5,6,5,4,5,4,3,4]

#x = [
 #    [4,2,3,4,5,4,5,6,7,4,8,9,8,8,6,6,5,5,5,5,5,5,5],
 #    [4,1,2,3,4,5,6,7,5,8,7,8,7,8,7,8,7,7,7,7,7,6,5],
 #    [4,1,2,5,6,7,8,9,7,8,7,8,7,7,7,7,7,7,6,6,4,4,4]
 #    ]


x = [
        [-2.96,-5.92,-8.88,-5.92,-8.88,-5.92,-11.84,-5.92,-14.81,-8.88],
        [-11.84,-5.92,-2.96,-11.84,-11.84,-11.84,-11.84,-11.84,-11.84,-5.92],
        [-14.81,-14.81,-17.77,-14.81,-17.77,-17.77,-20.73,-17.77,-20.73,-23.69],
        [0.0,-5.92,-8.88,-11.84,-8.88,-14.81,-11.84,-14.81,-11.84,-11.84]
    ]

y = [1047.27,1047.27,992.58,1047.27,1019.92,1047.27,1074.61,1074.61,1019.92,1129.3]

      
def reg_multiple(y, x):
   ones = np.ones(len(x[0]))
   X = add_constant(np.column_stack((x[0], ones)))
   for ele in x[1:]:
        X = add_constant(np.column_stack((ele, X)))
   results = OLS(y, X).fit()
   return results
   #return {"result":results.summary(), "PredictedValue":results.predict()}
#print(reg_multiple(y, x))

regResult= reg_multiple(y, x)
print (regResult.summary())
print (regResult.params)
print (regResult.bse)
print (regResult.predict())
y_predict = regResult.predict()

print (regResult.fittedvalues)



#plt.savefig('Multi_reg_graph.png')
#plt.show()

#plt.figure();
#plt.plot(x, y_predict, 'o', x, y, 'b-');
#prstd, iv_l, iv_u = wls_prediction_std(regResult);
#plt.plot(x, regResult.fittedvalues, 'r--.');
#plt.plot(x, iv_u, 'r--');
#plt.plot(x, iv_l, 'r--');
#plt.title('blue: true,   red: OLS');
         
#plt.savefig('Multi_reg_graph.png')
#plt.show()


#def reg_m(y, x):
#    ones = np.ones(len(x[0]))
 #   X = sm.add_constant(np.column_stack((x[0], ones)))
 #   for ele in x[1:]:
 #       X = sm.add_constant(np.column_stack((ele, X)))
 #   results = sm.OLS(y, X).fit()
 #   return results
#print (reg_m(y, x).summary())
import numpy as np
import statsmodels.api as sm


class Regression:
  y = []
  x = []
  strainGauge1 = []
  strainGauge2=[]
  strainGauge3 = []
  strainGauge4=[]
  #json = list()
  json=[{"elevatorPosition":-7.36,"peakValleyIndicator":1,"flightId":101,"flapPosition":15.15,"fleetId":1,"verticalAcceleration":1.0,"rollAcceleration":-0.87,"leftAileronPosition":0.36,"startTime":"22:49","retardantDoorOpen":1.00,"timestamp":"49:32.2","pressureAltitude":1047.27,"strainGauge3":-14.81,"retardantTankFloat":-3.68,"strainGauge2":-11.84,"strainGauge1":-2.96,"triggerChannel":1,"recordType":"PE","airspeed":54.2,"gearUpAndLocked":0.00,"armRetardantTankDoor":0.00,"strainGauge8":8.88,"beaconStartStopRecording":0.00,"strainGauge7":11.84,"strainGauge6":-5.92,"strainGauge5":-5.92,"startDate":"6-26-2004","elapsedTime":14.18,"strainGauge4":0.0},{"elevatorPosition":-7.31,"peakValleyIndicator":1,"flightId":101,"flapPosition":15.14,"fleetId":2,"verticalAcceleration":1.0,"rollAcceleration":-0.88,"leftAileronPosition":0.36,"startTime":"22:49","retardantDoorOpen":1.00,"timestamp":"49:47.2","pressureAltitude":1047.27,"strainGauge3":-14.81,"retardantTankFloat":-5.26,"strainGauge2":-5.92,"strainGauge1":-5.92,"triggerChannel":1,"recordType":"PE","airspeed":1,"gearUpAndLocked":0.00,"armRetardantTankDoor":0.00,"strainGauge8":11.84,"beaconStartStopRecording":0.00,"strainGauge7":5.92,"strainGauge6":-8.88,"strainGauge5":-8.88,"startDate":"6-26-2004","elapsedTime":29.18,"strainGauge4":-5.92},{"elevatorPosition":-7.31,"peakValleyIndicator":1,"flightId":101,"flapPosition":0.0,"fleetId":3,"verticalAcceleration":1.01,"rollAcceleration":-0.89,"leftAileronPosition":0.33,"startTime":"22:49","retardantDoorOpen":1.00,"timestamp":"50:02.2","pressureAltitude":992.58,"strainGauge3":-17.77,"retardantTankFloat":-2.11,"strainGauge2":-2.96,"strainGauge1":-8.88,"triggerChannel":1,"recordType":"PE","airspeed":54.2,"gearUpAndLocked":0.00,"armRetardantTankDoor":0.00,"strainGauge8":11.84,"beaconStartStopRecording":0.00,"strainGauge7":11.84,"strainGauge6":-8.88,"strainGauge5":-8.88,"startDate":"6-26-2004","elapsedTime":44.18,"strainGauge4":-8.88},{"elevatorPosition":-7.31,"peakValleyIndicator":1,"flightId":101,"flapPosition":0.0,"fleetId":4,"verticalAcceleration":1.01,"rollAcceleration":-0.89,"leftAileronPosition":0.42,"startTime":"22:49","retardantDoorOpen":1.00,"timestamp":"50:17.2","pressureAltitude":1047.27,"strainGauge3":-14.81,"retardantTankFloat":-6.83,"strainGauge2":-11.84,"strainGauge1":-5.92,"triggerChannel":1,"recordType":"PE","airspeed":53.93,"gearUpAndLocked":0.00,"armRetardantTankDoor":0.00,"strainGauge8":11.84,"beaconStartStopRecording":0.00,"strainGauge7":11.84,"strainGauge6":-5.92,"strainGauge5":-8.88,"startDate":"6-26-2004","elapsedTime":59.18,"strainGauge4":-11.84},{"elevatorPosition":-7.33,"peakValleyIndicator":1,"flightId":101,"flapPosition":-0.03,"fleetId":5,"verticalAcceleration":1.0,"rollAcceleration":-0.88,"leftAileronPosition":0.42,"startTime":"22:49","retardantDoorOpen":1.00,"timestamp":"50:32.2","pressureAltitude":1019.92,"strainGauge3":-17.77,"retardantTankFloat":-3.68,"strainGauge2":-11.84,"strainGauge1":-8.88,"triggerChannel":1,"recordType":"PE","airspeed":53.65,"gearUpAndLocked":0.00,"armRetardantTankDoor":0.00,"strainGauge8":11.84,"beaconStartStopRecording":0.00,"strainGauge7":11.84,"strainGauge6":-8.88,"strainGauge5":-8.88,"startDate":"6-26-2004","elapsedTime":74.18,"strainGauge4":-8.88},{"elevatorPosition":-7.31,"peakValleyIndicator":1,"flightId":101,"flapPosition":0.0,"fleetId":6,"verticalAcceleration":1.0,"rollAcceleration":-0.9,"leftAileronPosition":0.39,"startTime":"22:49","retardantDoorOpen":1.00,"timestamp":"50:47.2","pressureAltitude":1047.27,"strainGauge3":-17.77,"retardantTankFloat":-5.26,"strainGauge2":-11.84,"strainGauge1":-5.92,"triggerChannel":1,"recordType":"PE","airspeed":54.75,"gearUpAndLocked":0.00,"armRetardantTankDoor":0.00,"strainGauge8":11.84,"beaconStartStopRecording":0.00,"strainGauge7":11.84,"strainGauge6":-8.88,"strainGauge5":-8.88,"startDate":"6-26-2004","elapsedTime":89.18,"strainGauge4":-14.81},{"elevatorPosition":-7.36,"peakValleyIndicator":1,"flightId":101,"flapPosition":-0.01,"fleetId":7,"verticalAcceleration":1.0,"rollAcceleration":-0.87,"leftAileronPosition":0.42,"startTime":"22:49","retardantDoorOpen":1.00,"timestamp":"51:02.2","pressureAltitude":1074.61,"strainGauge3":-20.73,"retardantTankFloat":-6.83,"strainGauge2":-11.84,"strainGauge1":-11.84,"triggerChannel":1,"recordType":"PE","airspeed":53.93,"gearUpAndLocked":0.00,"armRetardantTankDoor":0.00,"strainGauge8":11.84,"beaconStartStopRecording":0.00,"strainGauge7":11.84,"strainGauge6":-8.88,"strainGauge5":-11.84,"startDate":"6-26-2004","elapsedTime":104.18,"strainGauge4":-11.84},{"elevatorPosition":-7.33,"peakValleyIndicator":1,"flightId":101,"flapPosition":0.0,"fleetId":8,"verticalAcceleration":1.01,"rollAcceleration":-0.89,"leftAileronPosition":0.33,"startTime":"22:49","retardantDoorOpen":1.00,"timestamp":"51:17.2","pressureAltitude":1074.61,"strainGauge3":-17.77,"retardantTankFloat":-3.68,"strainGauge2":-11.84,"strainGauge1":-5.92,"triggerChannel":1,"recordType":"PE","airspeed":54.48,"gearUpAndLocked":0.00,"armRetardantTankDoor":0.00,"strainGauge8":14.81,"beaconStartStopRecording":1.00,"strainGauge7":5.92,"strainGauge6":-8.88,"strainGauge5":-5.92,"startDate":"6-26-2004","elapsedTime":119.18,"strainGauge4":-14.81},{"elevatorPosition":-7.31,"peakValleyIndicator":1,"flightId":101,"flapPosition":-0.01,"fleetId":9,"verticalAcceleration":1.01,"rollAcceleration":-0.88,"leftAileronPosition":0.45,"startTime":"22:49","retardantDoorOpen":1.00,"timestamp":"51:32.2","pressureAltitude":1019.92,"strainGauge3":-20.73,"retardantTankFloat":-2.11,"strainGauge2":-11.84,"strainGauge1":-14.81,"triggerChannel":1,"recordType":"PE","airspeed":53.93,"gearUpAndLocked":0.00,"armRetardantTankDoor":0.00,"strainGauge8":14.81,"beaconStartStopRecording":1.00,"strainGauge7":11.84,"strainGauge6":-8.88,"strainGauge5":-8.88,"startDate":"6-26-2004","elapsedTime":134.18,"strainGauge4":-11.84},{"elevatorPosition":-7.28,"peakValleyIndicator":1,"flightId":101,"flapPosition":-0.01,"fleetId":10,"verticalAcceleration":0.99,"rollAcceleration":-0.88,"leftAileronPosition":0.42,"startTime":"22:49","retardantDoorOpen":1.00,"timestamp":"51:47.2","pressureAltitude":1129.3,"strainGauge3":-23.69,"retardantTankFloat":-8.40,"strainGauge2":-5.92,"strainGauge1":-8.88,"triggerChannel":1,"recordType":"PE","airspeed":53.93,"gearUpAndLocked":0.00,"armRetardantTankDoor":0.00,"strainGauge8":11.84,"beaconStartStopRecording":1.00,"strainGauge7":11.84,"strainGauge6":-8.88,"strainGauge5":-11.84,"startDate":"6-26-2004","elapsedTime":149.18,"strainGauge4":-11.84}]
  def jsonToArray(self,jsonStr):
       for i in range(len(jsonStr)):
           Regression.y.append(jsonStr[i]['pressureAltitude'])
           Regression.strainGauge1.append(jsonStr[i]["strainGauge1"])
           Regression.strainGauge2.append(jsonStr[i]['strainGauge2'])
           Regression.strainGauge3.append(jsonStr[i]['strainGauge3'])
           Regression.strainGauge4.append(jsonStr[i]['strainGauge4'])
#    print (y)
  x.append(strainGauge1)
  x.append(strainGauge2)
  x.append(strainGauge3)
  x.append(strainGauge4)
 #   print(x)
   
    
#print(jsonToArray(json))
  def reg_multiple(self,y, x):
     Regression.jsonToArray(Regression.json)
     ones = np.ones(len(x[0]))
     X = sm.add_constant(np.column_stack((x[0], ones)))
     for ele in x[1:]:
        X = sm.add_constant(np.column_stack((ele, X)))
     results = sm.OLS(y, X).fit()
#     return results
     return {"result":results.summary(), "PredictedValue":results.predict()}
#print(reg_multiple(y, x))

#  regResult =reg_multiple(y, x) 
 # print (regResult.summary())
 # print (regResult.params)
#  print (regResult.bse)
#  print (regResult.predict())
  #y_predict = reg_multiple(y, x).predict()

#print (y_predict)
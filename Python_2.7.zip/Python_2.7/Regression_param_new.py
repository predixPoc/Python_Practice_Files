import json
import pandas as pd
from statsmodels.formula.api import ols

class Regression:
  def __init__(self):
      print ("Create multi linear regression")
  
  def reg_multiple(self,data):
     #print(data)
     data_json = json.loads(data)
     print("After loading json")
     #print(data_json)
     y = data_json.get("strainGauge")
     print("y data :::")
     #print(y)
     #print("\n\n")
     inputParameters=data_json.get("inputParam")
     print("Input Parameters :::: ")
     print(inputParameters)
     #print(len(inputParameters))
     i=0
     param=''
     for i in range(len(inputParameters)):
         if(i==0):
            param=inputParameters[i]
         else:
            param= param + "+" + inputParameters[i];
     
     print(param)
     f="strainGauge ~ " + param
     print(f)
     del data_json['inputParam']
     #print(data_json)
     df = pd.DataFrame(data_json)
     results = ols(formula=f, data=df).fit()
     # results = OLS(y,X).fit()
     #print (results.summary())
     return {"ActualValue":y,"PredictedValue":results.predict().tolist(),"Coeff":results.params.tolist(),"StdError":results.bse.tolist(),
     "tValue":results.tvalues.tolist(),"pValue":results.pvalues.tolist(),"RSquared":results.rsquared}




from .linear_model import yule_walker

from statsmodels import NoseWrapper as Tester
test = Tester().test

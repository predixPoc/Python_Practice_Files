import json
import numpy as np
from statsmodels.regression.linear_model import OLS
from statsmodels.tools.tools import add_constant

class Regression:
  def __init__(self):
      print ("Create multi linear regression")
  
  def reg_multiple(self,data):
     #print(data)
     data_json = json.loads(data)
     print("After loading json")
     #print(data_json)
     y = data_json.get("strainGauge")
     print("y data :::")
     #print(y)
     #print("\n\n")
     x1 = data_json.get("airspeed")
     #print("x1 = ")
     #print(x1)
     #print("\n\n")
     x2 = data_json.get("pressureAltitude")
     #print("x2 = ")
     #print(x2)
     #print("\n\n")
     x3 = data_json.get("rollAcceleration")
     #print("x3 = ")
     #print(x3)
     #print("\n\n")
     x4 = data_json.get("verticalAcceleration")
     x5 = data_json.get("dPeakValley")
     x6 = data_json.get("flapPosition")
     x7 = data_json.get("elevatorPosition")
     x8 = data_json.get("redudantDoorOpen")
     x9 = data_json.get("gearupLock")
     x = []
     x.append(x1)
     x.append(x2)
     x.append(x3)
     x.append(x4)
     x.append(x5)
     x.append(x6)
     x.append(x7)
     x.append(x8)
     x.append(x9)
	 
     #print(x)
     ones = np.ones(len(x[0]))
     X = add_constant(np.column_stack((x[0], ones)))
     for ele in x[1:]:
        X = add_constant(np.column_stack((ele, X)))
     results = OLS(y, X).fit()
     return {"ActualValue":y,"PredictedValue":results.predict().tolist(),"Coeff":results.params.tolist(),"StdError":results.bse.tolist(),
     "tValue":results.tvalues.tolist(),"pValue":results.pvalues.tolist(),"RSquared":results.rsquared}


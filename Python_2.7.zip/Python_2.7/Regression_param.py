import json
import numpy as np
from statsmodels.regression.linear_model import OLS
from statsmodels.tools.tools import add_constant

class Regression:
  def __init__(self):
      print ("Create multi linear regression")
  
  def reg_multiple(self,data):
     #print(data)
     data_json = json.loads(data)
     print("After loading json")
     #print(data_json)
     y = data_json.get("strainGauge")
     print("y data :::")
     #print(y)
     #print("\n\n")
     x = []
     inputParameters=data_json.get("inputParam")
     print("Input Parameters :::: ")
     print(inputParameters)
     #print(len(inputParameters))
     i=0
     for i in range(len(inputParameters)):
         x.append(data_json.get(inputParameters[i]))
 
     #print(x)
     ones = np.ones(len(x[0]))
     X = add_constant(np.column_stack((x[0], ones)))
     for ele in x[1:]:
        X = add_constant(np.column_stack((ele, X)))
     results = OLS(y, X).fit()
     return {"ActualValue":y,"PredictedValue":results.predict().tolist(),"Coeff":results.params.tolist(),"StdError":results.bse.tolist(),
     "tValue":results.tvalues.tolist(),"pValue":results.pvalues.tolist(),"RSquared":results.rsquared}


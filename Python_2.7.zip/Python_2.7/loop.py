# -*- coding: utf-8 -*-

list2 = [123, 'xyz', 'zara']
list2.reverse()
print(list2)


